<?php
$host='localhost'; $user='root'; $pass=''; $db='undangan';
$conn = new mysqli($host, $user, $pass, $db);
?>